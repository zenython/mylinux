# chardet

chardet is library to automatically detect
[charset](http://en.wikipedia.org/wiki/Character_encoding) of texts for [Go
programming language](http://golang.org/). It's based on the algorithm and data
in [ICU](http://icu-project.org/)'s implementation.

## Documentation and Usage

See [pkgdoc](https://pkg.go.dev/github.com/saintfish/chardet)
