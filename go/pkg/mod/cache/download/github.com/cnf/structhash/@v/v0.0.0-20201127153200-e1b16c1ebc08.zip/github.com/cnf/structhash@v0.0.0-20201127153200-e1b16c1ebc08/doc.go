/*
Package structhash creates hash strings from arbitrary go data structures.
*/
package structhash
