#!/bin/sh
/usr/bin/time -f '%Uu %Ss %er %MkB %C' "$@"
