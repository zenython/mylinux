[![GoDoc](https://godoc.org/github.com/lor00x/goldap?status.svg)](https://godoc.org/github.com/lor00x/goldap)
[![Build Status](https://travis-ci.org/lor00x/goldap.svg)](https://travis-ci.org/lor00x/goldap)
[![Coverage Status](https://coveralls.io/repos/lor00x/goldap/badge.png?branch=master)](https://coveralls.io/r/lor00x/goldap?branch=master)

# LDAP library in Golang

This library performs decoding and encoding of LDAP message.
It still requires a lot of testing.

# Usage example
See my [LDAP proxy](https://github.com/lor00x/goldap-proxy).
See [LDAP Server](https://github.com/vjeantet/ldapserver).
