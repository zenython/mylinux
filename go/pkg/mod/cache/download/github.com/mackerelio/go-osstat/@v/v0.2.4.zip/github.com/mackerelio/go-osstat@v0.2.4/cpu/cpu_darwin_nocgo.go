//go:build darwin && !cgo
// +build darwin,!cgo

package cpu

// CPU counters for darwin is unavailable without cgo.
