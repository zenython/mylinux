# Overview

A lib to encode/decode the data of the cdp protocol.

This lib is standalone and stateless, you can use it independently. Such as use it to encode/decode JSON with other libs that can drive browsers.

Here's an [usage example](https://github.com/go-rod/rod/blob/9e847f3bab313a1d233c0c868fe5125e2e70de70/examples_test.go#L370-L393).
