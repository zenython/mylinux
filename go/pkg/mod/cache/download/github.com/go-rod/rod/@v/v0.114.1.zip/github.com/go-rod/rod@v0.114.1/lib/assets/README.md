# Assets

Static files for the project
