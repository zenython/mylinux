# input

A lib to help encode inputs.
