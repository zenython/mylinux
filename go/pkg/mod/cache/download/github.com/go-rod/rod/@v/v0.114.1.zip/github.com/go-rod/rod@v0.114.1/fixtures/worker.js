// echo message
onmessage = (e) => postMessage(e.data)
