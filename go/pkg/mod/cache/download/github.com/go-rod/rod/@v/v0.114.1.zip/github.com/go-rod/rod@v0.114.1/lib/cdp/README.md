# Overview

This client is directly based on this [doc](https://chromedevtools.github.io/devtools-protocol/).

You can treat it as a minimal example of how to use the DevTools Protocol, no complex abstraction.

It's thread-safe, and context first.

For basic usage, check this [file](example_test.go).

For more info, check the unit tests.
