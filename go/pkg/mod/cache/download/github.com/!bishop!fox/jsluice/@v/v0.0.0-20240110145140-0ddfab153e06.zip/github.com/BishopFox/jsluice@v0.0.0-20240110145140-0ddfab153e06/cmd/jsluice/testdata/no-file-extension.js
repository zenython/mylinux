function C() {
        return C = (0, o.default)(c().mark(function e(t) {
                return c().wrap(function (e) {
                    while (1)
                        switch (e.prev = e.next) {
                        case 0:
                            return e.abrupt("return", (0, i.default)("/admin/article/paging", {
                                    method: "POST",
                                    body: t
                                }));
                        case 1:
                        case "end":
                            return e.stop()
                        }
                }, e)
            })),
        C.apply(this, arguments)
    }
