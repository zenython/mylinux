const container = () => {
    const Ae = {
        apiKey: "AIzaSyB47WKzDu9kkmFAsAYFlagkuJxdEXAMPLE",
        authDomain: "someauthdomain.firebaseapp.com",
        projectId: "someprojectid",
        storageBucket: "somebucketthatisnotthere.appspot.com",
        messagingSenderId: "586572527435",
        appId: "1:586572527435:web:14c624679103dc3e74b755"
    };
}
