function getConfig(){
    let config = {
        randomStr: "abc123xyz256",
        secret: "I quite like PHP",
    }
    return "eyJsb2wiOiAic29tZSBKU09OISIsICJjb3VudCI6IDEyM30K"
}
