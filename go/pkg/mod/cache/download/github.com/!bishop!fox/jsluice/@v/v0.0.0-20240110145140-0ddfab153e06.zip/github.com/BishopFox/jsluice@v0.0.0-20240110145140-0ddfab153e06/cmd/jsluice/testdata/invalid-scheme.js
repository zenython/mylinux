document.location = "some-scheme://footle.com"
