var config = {
    bucket: "examplebucket",
    awsKey: "AKIAIOSFODNN7EXAMPLE",
    awsSecret: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    server: "someserver.example.com"
};

var notAKey = {
    awskey: "ASIAN ZING CAULIFLOWER BITES",
    "secret": "This isn't a secret; why does it say that?!"
}
