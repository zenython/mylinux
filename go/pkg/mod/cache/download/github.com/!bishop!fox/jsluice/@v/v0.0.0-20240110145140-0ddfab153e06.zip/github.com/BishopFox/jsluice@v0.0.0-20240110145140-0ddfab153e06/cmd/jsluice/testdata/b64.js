(function(){
    let foo = {
        "env": "prod",
        "secret": "sometimesIWritePHP"
    }
    return {
        aThing: "eyJsb2wiOiAic29tZSBKU09OISIsICJjb3VudCI6IDEyM30K",
        "anotherThing": 123,
        private: "keepOut"
    }
})()
