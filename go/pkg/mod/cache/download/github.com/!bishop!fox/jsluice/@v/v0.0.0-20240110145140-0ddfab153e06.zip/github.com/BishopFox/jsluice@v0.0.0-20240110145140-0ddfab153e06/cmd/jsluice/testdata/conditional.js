var abc = 123; if (abc < 124) { console.log("math is fine") } else { console.log("math is broken")}
