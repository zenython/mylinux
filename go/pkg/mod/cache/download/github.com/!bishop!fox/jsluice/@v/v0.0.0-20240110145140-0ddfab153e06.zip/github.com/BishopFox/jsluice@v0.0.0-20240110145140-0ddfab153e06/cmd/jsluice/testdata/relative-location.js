document.location = '../../guestbook.html'
