let str = 'Hello,\x20World!'
