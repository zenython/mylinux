(function(){
    var config = {
        noIdea: "what",
        cloneURL: "https://Some-User:ghp_BsE8x5x89jzGZxbQgFJNi4tkxs1F4EXAMPLE@github.com/foo/bar.git"
    };
    return function(){ return config; };
})();
