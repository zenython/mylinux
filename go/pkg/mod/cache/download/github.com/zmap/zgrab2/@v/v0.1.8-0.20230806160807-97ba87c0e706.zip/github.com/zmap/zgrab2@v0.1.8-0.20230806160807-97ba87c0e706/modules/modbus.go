package modules

import "github.com/zmap/zgrab2/modules/modbus"

func init() {
	modbus.RegisterModule()
}
