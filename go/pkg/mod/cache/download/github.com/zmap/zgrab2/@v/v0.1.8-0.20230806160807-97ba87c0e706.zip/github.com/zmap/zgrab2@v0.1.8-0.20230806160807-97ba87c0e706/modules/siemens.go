package modules

import "github.com/zmap/zgrab2/modules/siemens"

func init() {
	siemens.RegisterModule()
}
