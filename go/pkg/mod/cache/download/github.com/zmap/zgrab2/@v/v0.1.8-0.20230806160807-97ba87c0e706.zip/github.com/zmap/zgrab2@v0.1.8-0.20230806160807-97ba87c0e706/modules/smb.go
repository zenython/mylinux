package modules

import "github.com/zmap/zgrab2/modules/smb"

func init() {
	smb.RegisterModule()
}
