package modules

import "github.com/zmap/zgrab2/modules/fox"

func init() {
	fox.RegisterModule()
}
