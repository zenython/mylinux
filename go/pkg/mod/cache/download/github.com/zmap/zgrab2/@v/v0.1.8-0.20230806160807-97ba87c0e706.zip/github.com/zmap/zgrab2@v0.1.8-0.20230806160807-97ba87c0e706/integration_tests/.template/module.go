package modules

import "github.com/zmap/zgrab2/modules/#{MODULE_NAME}"

func init() {
	#{MODULE_NAME}.RegisterModule()
}
