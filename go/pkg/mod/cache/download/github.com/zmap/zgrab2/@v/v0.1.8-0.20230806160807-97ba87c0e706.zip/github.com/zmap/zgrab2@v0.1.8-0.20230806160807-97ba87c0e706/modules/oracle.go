package modules

import "github.com/zmap/zgrab2/modules/oracle"

func init() {
	oracle.RegisterModule()
}
