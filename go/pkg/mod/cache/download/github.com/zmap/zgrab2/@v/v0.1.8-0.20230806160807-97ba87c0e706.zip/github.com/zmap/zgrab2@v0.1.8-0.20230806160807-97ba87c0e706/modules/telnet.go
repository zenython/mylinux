package modules

import "github.com/zmap/zgrab2/modules/telnet"

func init() {
	telnet.RegisterModule()
}
