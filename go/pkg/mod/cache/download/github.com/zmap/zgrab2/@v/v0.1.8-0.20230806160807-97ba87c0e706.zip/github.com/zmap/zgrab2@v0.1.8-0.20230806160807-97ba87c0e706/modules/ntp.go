package modules

import "github.com/zmap/zgrab2/modules/ntp"

func init() {
	ntp.RegisterModule()
}
