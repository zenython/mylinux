BER Package
============

[![Build Status](https://travis-ci.org/geoffgarside/ber.svg?branch=master)](https://travis-ci.org/geoffgarside/ber)
[![GoDoc](https://godoc.org/github.com/geoffgarside/ber?status.svg)](http://godoc.org/github.com/geoffgarside/ber)

This package is a fork of the standard library `encoding/asn1` package, adding Basic Encoding Rules support for use with [`github.com/k-sone/snmpgo`](https://github.com/k-sone/snmpgo).
