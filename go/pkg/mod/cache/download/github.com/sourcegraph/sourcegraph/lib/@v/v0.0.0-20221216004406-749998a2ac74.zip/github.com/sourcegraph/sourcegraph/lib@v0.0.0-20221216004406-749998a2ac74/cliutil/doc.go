// Package cliutil and its subpackages provide utilities for the github.com/urfave/cli/v2
// library and CLIs at Sourcegraph in general.
package cliutil
