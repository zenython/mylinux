# LSIF protocol utilities for Go

This repository contains LSIF protocol struct definitions.
