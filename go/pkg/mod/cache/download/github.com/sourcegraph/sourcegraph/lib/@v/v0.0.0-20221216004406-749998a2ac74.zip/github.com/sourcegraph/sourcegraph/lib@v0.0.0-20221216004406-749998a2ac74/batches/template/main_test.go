package template

var testRepo1 = &Repository{
	Name: "github.com/sourcegraph/src-cli",
	FileMatches: []string{
		"main.go", "README.md",
	},
}
