# Release Notes v0.5.10

This release fixes issue #40. Many thanks to Github user Misuo Heijo for fuzzing
the xz module.
