#!/usr/bin/env bash
complete -W "\$(pencode -list)" pencode