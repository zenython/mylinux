package pencode

const VERSION = "0.3"
