// Package extractors implements extractors for http response
// data retrieval.
package extractors
