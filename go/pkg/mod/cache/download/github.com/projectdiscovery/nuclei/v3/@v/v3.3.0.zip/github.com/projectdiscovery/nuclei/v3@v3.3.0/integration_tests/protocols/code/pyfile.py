import sys
print("hello from " + sys.stdin.read())