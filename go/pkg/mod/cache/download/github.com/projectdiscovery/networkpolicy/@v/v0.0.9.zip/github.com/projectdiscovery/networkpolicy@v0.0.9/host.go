package networkpolicy

var DefaultHostDenylist = []string{
	"localhost", // Localhost
}
