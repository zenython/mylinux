package asnmap

// Version is the current Version of asnmap
const Version = `v1.1.0`
