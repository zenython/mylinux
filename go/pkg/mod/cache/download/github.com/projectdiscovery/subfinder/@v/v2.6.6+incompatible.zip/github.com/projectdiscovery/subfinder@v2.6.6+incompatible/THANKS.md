### Thanks

Many people have contributed to subfinder making it a wonderful tool either by making a pull request fixing some stuff or giving generous donations to support the furthur development of this tool. Here, we recognize these persons and thank them. 

- All the contributors at [CONTRIBUTORS](https://github.com/projectdiscovery/subfinder/graphs/contributors) who made subfinder what it is.

We'd like to thank some additional amazing people, who contributed a lot in subfinder's journey - 

- [@vzamanillo](https://github.com/vzamanillo) - For adding multiple features and overall project improvements.
- [@infosec-au](https://github.com/infosec-au) - Donating to the project.
- [@codingo](https://github.com/codingo) - Initial work on the project, managing it, lot of work!
- [@picatz](https://github.com/picatz) - Improving the structure of the project a lot. New ideas!