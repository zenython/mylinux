// package patterns contains various common patterns
// some regexps were extended from https://github.com/asaskevich/govalidator
package patterns
