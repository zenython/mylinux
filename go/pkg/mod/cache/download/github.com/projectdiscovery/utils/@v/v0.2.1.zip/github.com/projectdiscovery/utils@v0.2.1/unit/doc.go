// unit contains common values:
// - units size (ex. byte, kilo, mega, giga)
package unit
