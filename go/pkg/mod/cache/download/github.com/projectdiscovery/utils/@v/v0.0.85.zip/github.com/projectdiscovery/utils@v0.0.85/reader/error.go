package reader

import "errors"

var ErrTimeout = errors.New("Timeout")
