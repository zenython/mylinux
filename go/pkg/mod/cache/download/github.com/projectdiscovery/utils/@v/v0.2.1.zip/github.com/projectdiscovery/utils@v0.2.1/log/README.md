# logutil
The package contains helpers to interact with logs
