# raceutil
The package contains various helpers for race
