package memoize

import _ "embed"

//go:embed package_template.tpl
var PackageTemplate string
