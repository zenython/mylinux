# permissionutils
The package contains various helpers about permissions/privileges
