# executil
The package contains various helpers to interact binary execution