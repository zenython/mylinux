package unit

const (
	Byte = 1
	Kilo = 1024
	Mega = 1024 * 1024
	Giga = 1024 * 1024 * 1024
)
