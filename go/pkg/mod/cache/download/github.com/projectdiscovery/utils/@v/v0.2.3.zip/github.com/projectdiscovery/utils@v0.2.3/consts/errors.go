package consts

import "errors"

var (
	ErrNotSupported = errors.New("not supported")
)
