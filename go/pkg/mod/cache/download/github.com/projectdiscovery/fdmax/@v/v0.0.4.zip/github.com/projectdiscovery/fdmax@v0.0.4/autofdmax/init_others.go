//go:build windows || freebsd || dragonfly || plan9

package autofdmax

func init() {
	// not implemented
}
