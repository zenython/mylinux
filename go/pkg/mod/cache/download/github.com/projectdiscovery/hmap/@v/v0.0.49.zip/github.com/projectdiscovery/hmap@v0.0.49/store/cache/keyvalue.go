package cache

type keyAndValue struct {
	key   string
	value interface{}
}
