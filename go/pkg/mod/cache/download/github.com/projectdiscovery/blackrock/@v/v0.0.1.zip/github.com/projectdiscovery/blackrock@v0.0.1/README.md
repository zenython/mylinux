# blackrock
blackrock cipher based on masscan 

the cipher allows to visit all the elements of a finite space only once in a pseudo-random way