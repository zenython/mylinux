// metafiles are metadata files related to networking like
// /etc/hosts etc
package metafiles
