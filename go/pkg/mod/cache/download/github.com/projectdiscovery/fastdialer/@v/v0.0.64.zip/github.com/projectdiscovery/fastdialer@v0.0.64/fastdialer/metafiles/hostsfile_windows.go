//go:build windows
// +build windows

package metafiles

const HostsFilePath = "${SystemRoot}/System32/drivers/etc/hosts"
