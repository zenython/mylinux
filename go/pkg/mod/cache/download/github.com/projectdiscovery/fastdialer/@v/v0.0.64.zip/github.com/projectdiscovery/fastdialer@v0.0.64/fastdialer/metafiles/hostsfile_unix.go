//go:build !windows
// +build !windows

package metafiles

// HostsFilePath in unix file os
const HostsFilePath = "/etc/hosts"
