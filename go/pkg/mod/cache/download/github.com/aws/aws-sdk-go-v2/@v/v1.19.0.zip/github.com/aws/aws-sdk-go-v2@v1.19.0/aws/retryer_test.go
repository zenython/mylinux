package aws

var _ RetryerV2 = NopRetryer{}
