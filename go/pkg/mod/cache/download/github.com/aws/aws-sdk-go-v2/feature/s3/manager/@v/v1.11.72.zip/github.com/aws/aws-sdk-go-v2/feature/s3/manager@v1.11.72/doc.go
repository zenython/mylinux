// Package manager provides utilities to upload and download objects from
// S3 concurrently. Helpful for when working with large objects.
package manager
