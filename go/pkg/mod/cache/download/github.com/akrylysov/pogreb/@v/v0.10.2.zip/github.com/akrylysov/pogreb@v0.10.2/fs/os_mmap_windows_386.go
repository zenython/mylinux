package fs

import (
	"math"
)

const maxMmapSize = math.MaxInt32
