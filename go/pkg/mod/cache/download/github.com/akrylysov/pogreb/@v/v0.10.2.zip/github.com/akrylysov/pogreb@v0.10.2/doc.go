/*
Package pogreb implements an embedded key-value store for read-heavy workloads.
*/
package pogreb
