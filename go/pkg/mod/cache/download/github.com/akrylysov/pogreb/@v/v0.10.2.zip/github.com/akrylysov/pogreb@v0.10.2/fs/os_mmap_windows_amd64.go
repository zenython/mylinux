package fs

const maxMmapSize = 1 << 48
