This library uses GitHub releases to document the changelog. See https://github.com/AzureAD/microsoft-authentication-library-for-go/releases
