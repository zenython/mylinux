package domainutil

//go:generate go run github.com/bobesa/go-domain-util/cmd/domainparser
