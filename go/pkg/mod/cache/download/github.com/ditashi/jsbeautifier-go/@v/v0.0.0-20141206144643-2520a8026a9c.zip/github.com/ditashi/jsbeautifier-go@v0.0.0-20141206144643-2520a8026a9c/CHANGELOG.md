# Changelog

## v0.3
 * Various bug fixes, passes most of the original jsbeautifier tests

## v0.2
* Semi-Tested Unicode support, converted most of the code to use Go's rune parsing methods, seems to be fine but needs more testing
* Untested Regex parsing
* Some edge cases fixed

## v0.1
* Initial release