// Package fileoperation provides a set of functions commonly used on files.
package fileoperation
