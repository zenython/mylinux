// Package filetest provides utility functions that can be used during unit testing.
// Any resource created by the package during a test is cleaned up automatically when the test is done.
package filetest
