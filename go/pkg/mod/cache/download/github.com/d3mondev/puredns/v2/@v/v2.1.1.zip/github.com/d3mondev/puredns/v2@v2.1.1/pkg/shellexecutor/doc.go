// Package shellexecutor offers a basic ShellExecutor object that can be used to execute command-line applications.
package shellexecutor
