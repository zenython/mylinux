package synthetic

// Generator is a pseudo-random numbers generator.
type Generator interface {
	Int() int
}
