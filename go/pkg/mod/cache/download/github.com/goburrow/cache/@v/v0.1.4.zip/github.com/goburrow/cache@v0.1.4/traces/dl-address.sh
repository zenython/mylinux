#!/bin/sh
FILE="proj1-traces.tar.gz"
curl -O "http://cseweb.ucsd.edu/classes/fa07/cse240a/$FILE"
tar xvzf "$FILE"
