package main

import "github.com/LukaSikic/subzy/cmd"

func main() {
	cmd.Execute()
}
