goreleaser --skip-publish --rm-dist
