Contributions are welcome, but please open an issue for discussion before sending a pull request.
