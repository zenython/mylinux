// Package cipher provides data encryption algorithms.
package cipher
