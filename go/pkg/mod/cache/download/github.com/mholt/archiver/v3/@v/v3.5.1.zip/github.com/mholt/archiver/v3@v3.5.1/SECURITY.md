# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| >= 3.x  | :white_check_mark: |
| < 3.0   | :x:                |

## Reporting a Vulnerability

Please send the details to both of us:

- AJ ONeal <coolaj86@gmail.com>
- Matthew Holt <Matthew.Holt@gmail.com>
