ACMEz Examples
==============

- `plumbing`: Tutorial showing low-level ACME transaction using the `acme` package
- `porcelain`: Demonstrates how to use the `acmez` package for convenient ACME transactions

**Most users should follow the porcelain guide.** You only need the plumbing tutorial if you want to dig deep and have greater control over your ACME flow.

