// Package timefmt provides functions for formatting and parsing date time strings.
package timefmt
