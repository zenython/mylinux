# generic-list-go [![CI](https://github.com/bahlo/generic-list-go/actions/workflows/ci.yml/badge.svg)](https://github.com/bahlo/generic-list-go/actions/workflows/ci.yml)

Go [container/list](https://pkg.go.dev/container/list) but with generics.

The code is based on `container/list` in `go1.18beta2`.
