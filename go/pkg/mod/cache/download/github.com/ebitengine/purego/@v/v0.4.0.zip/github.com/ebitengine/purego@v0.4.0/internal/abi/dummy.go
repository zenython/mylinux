// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2022 The Ebitengine Authors

//go:build dummy

// Package abi is a dummy package that prevents go tooling from stripping the C dependencies.
package abi
