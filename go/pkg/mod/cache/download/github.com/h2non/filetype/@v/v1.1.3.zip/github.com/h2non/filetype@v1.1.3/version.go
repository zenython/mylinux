package filetype

// Version exposes the current package version.
const Version = "1.1.3"
