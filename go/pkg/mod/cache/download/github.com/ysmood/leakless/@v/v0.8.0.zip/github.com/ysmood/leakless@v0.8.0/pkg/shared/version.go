package shared

// Version ...
const Version = "0c3354cd58f0813bb5b34ddf3a7c16ed"
