# Overview

A simple lib to diff two string with pretty output. It also provide some low-level API to customize the output.
