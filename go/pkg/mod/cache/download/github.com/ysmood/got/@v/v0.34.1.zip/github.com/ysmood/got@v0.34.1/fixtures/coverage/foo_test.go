package coverage

import "testing"

func TestFoo(_ *testing.T) {
	Foo()
}
