
export function run(): Promise<void> {
	return new Promise(() => {});
}