// Package coverage ...
package coverage

// Foo ...
func Foo() int {
	return 1
}
