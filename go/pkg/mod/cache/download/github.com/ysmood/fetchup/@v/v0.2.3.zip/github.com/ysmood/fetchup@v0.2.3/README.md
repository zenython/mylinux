# Overview

A lib to fetch the target file from remote. It will auto choose the fastest url to download and decompress the file.
