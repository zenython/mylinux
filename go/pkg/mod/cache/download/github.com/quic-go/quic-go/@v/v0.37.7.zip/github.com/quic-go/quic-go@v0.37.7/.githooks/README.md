# Git Hooks

This directory contains useful Git hooks for working with quic-go.

Install them by running
```bash
git config core.hooksPath .githooks
```
