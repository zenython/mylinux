History
=======

### v0.3.4 / 2013-05-19

Add gostem program

### v0.3.3 / 2013-05-19

Add large vocabulary tests for each language

### v0.3.1 / 2013-05-18

Meaningless bump

### v0.3.0 / 2013-05-18

Add Russian stemmer.

### v0.2.0 / 2013-05-17

Add French stemmer and move more common code for romance
languages into the `romance` package.

### v0.1.1 / 2013-05-14

Documentation fixes.

### v0.1.0 / 2013-05-13

Added Spanish stemmer and started versioning the project.