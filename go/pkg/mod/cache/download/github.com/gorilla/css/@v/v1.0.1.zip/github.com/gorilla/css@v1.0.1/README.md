# gorilla/css

![testing](https://github.com/gorilla/css/actions/workflows/test.yml/badge.svg)
[![codecov](https://codecov.io/github/gorilla/css/branch/main/graph/badge.svg)](https://codecov.io/github/gorilla/css)
[![godoc](https://godoc.org/github.com/gorilla/css?status.svg)](https://godoc.org/github.com/gorilla/css)
[![sourcegraph](https://sourcegraph.com/github.com/gorilla/css/-/badge.svg)](https://sourcegraph.com/github.com/gorilla/css?badge)

![Gorilla Logo](https://github.com/gorilla/.github/assets/53367916/d92caabf-98e0-473e-bfbf-ab554ba435e5)

A CSS3 tokenizer.
