3. 3 is first and numbered 3
4. 4 is second and numbered 4
10. ten is third and numbered 5
